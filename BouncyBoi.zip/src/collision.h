#ifndef COLLISION_H
#define COLLISION_H

int collision(int playerRow, int playerCol, int playerWidth, int bunnyRow, int bunnyCol, int bunnyWidth);
int overlap(int buffRow, int buffCol, int bunnyRow, int bunnyCol, int bunnyWidth);

#endif