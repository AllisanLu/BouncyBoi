/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 platform platform.png 
 * Time-stamp: Sunday 11/07/2021, 01:05:12
 * 
 * Image Information
 * -----------------
 * platform.png 24@4
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLATFORM_H
#define PLATFORM_H

extern const unsigned short platform[96];
#define PLATFORM_SIZE 192
#define PLATFORM_LENGTH 96
#define PLATFORM_WIDTH 24
#define PLATFORM_HEIGHT 4

#endif

