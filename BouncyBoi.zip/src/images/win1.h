/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 win1 win1.png 
 * Time-stamp: Monday 11/08/2021, 20:19:18
 * 
 * Image Information
 * -----------------
 * win1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN1_H
#define WIN1_H

extern const unsigned short win1[38400];
#define WIN1_SIZE 76800
#define WIN1_LENGTH 38400
#define WIN1_WIDTH 240
#define WIN1_HEIGHT 160

#endif

