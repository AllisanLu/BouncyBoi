/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 verybouncyboi verybouncyboi.png 
 * Time-stamp: Saturday 11/06/2021, 19:25:16
 * 
 * Image Information
 * -----------------
 * verybouncyboi.png 24@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VERYBOUNCYBOI_H
#define VERYBOUNCYBOI_H

extern const unsigned short verybouncyboi[576];
#define VERYBOUNCYBOI_SIZE 1152
#define VERYBOUNCYBOI_LENGTH 576
#define VERYBOUNCYBOI_WIDTH 24
#define VERYBOUNCYBOI_HEIGHT 24

#endif

