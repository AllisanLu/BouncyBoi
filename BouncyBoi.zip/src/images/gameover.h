/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 gameover potato.jpg 
 * Time-stamp: Monday 11/08/2021, 19:52:41
 * 
 * Image Information
 * -----------------
 * potato.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEOVER_H
#define GAMEOVER_H

extern const unsigned short gameover[38400];
#define POTATO_SIZE 76800
#define POTATO_LENGTH 38400
#define POTATO_WIDTH 240
#define POTATO_HEIGHT 160

#endif

