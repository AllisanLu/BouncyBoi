/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 moon moon.png 
 * Time-stamp: Monday 11/08/2021, 23:13:18
 * 
 * Image Information
 * -----------------
 * moon.png 240@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MOON_H
#define MOON_H

extern const unsigned short moon[4800];
#define MOON_SIZE 9600
#define MOON_LENGTH 4800
#define MOON_WIDTH 240
#define MOON_HEIGHT 20

#endif

