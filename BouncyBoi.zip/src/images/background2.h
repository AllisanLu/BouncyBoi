/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 background2 background2.png 
 * Time-stamp: Saturday 11/06/2021, 16:59:06
 * 
 * Image Information
 * -----------------
 * background2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND2_H
#define BACKGROUND2_H

extern const unsigned short background2[38400];
#define BACKGROUND2_SIZE 76800
#define BACKGROUND2_LENGTH 38400
#define BACKGROUND2_WIDTH 240
#define BACKGROUND2_HEIGHT 160

#endif

