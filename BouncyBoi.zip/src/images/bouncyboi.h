/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 bouncyboi bouncyboi.png 
 * Time-stamp: Saturday 11/06/2021, 19:25:04
 * 
 * Image Information
 * -----------------
 * bouncyboi.png 24@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOUNCYBOI_H
#define BOUNCYBOI_H

extern const unsigned short bouncyboi[576];
#define BOUNCYBOI_SIZE 1152
#define BOUNCYBOI_LENGTH 576
#define BOUNCYBOI_WIDTH 24
#define BOUNCYBOI_HEIGHT 24

#endif

