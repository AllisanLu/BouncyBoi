#ifndef MOVEMENT_H
#define MOVEMENT_H

int moveBunny(int *row, int *speedR, int *col, int *speedC, int size);
void movePlatform(int *row, int speedR, int *col, int speedC, int width, int height);
#endif